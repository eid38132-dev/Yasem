plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.yasem"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.yasem"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.9"
    }
    // Wake-word engine can be enabled after adding the provider SDK and model.
}
