package com.example.yasem

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class YasemVoiceService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var recognizer: SpeechRecognizer
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1001, notification())
        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { restartSoon() }
            override fun onError(e: Int) { restartSoon() }
            override fun onResults(b: Bundle?) {
                val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.lowercase(Locale("ar","EG")) ?: ""
                handle(text)
                restartSoon()
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        restartSoon(700)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts.language = Locale("ar","EG")
    }

    private fun restartSoon(delay: Long = 500) {
        handler.postDelayed({
            if (!::recognizer.isInitialized) return@postDelayed
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-EG")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            try { recognizer.startListening(i) } catch (_: Exception) {}
        }, delay)
    }

    private fun normalize(s: String): String =
        s.replace("يا سم","ياسم").replace("يا سام","ياسم")
            .replace("ياصم","ياسم").replace("يا صم","ياسم").trim()

    private fun handle(raw: String) {
        val s = normalize(raw)
        if (!s.contains("ياسم")) return
        val cmd = s.substringAfter("ياسم").trim()
        if (cmd.isBlank()) { speak("معاك، قول لي عايز إيه"); return }

        when {
            any(cmd, "افتح الكاميرا","شغل الكاميرا","الكاميرا") -> openCamera()
            any(cmd, "الساعة كام","الوقت كام","كم الساعة") ->
                speak("الساعة الآن " + SimpleDateFormat("h:mm a", Locale("ar","EG")).format(Date()))
            any(cmd, "النهارده كام","تاريخ اليوم","تاريخ النهارده") ->
                speak("اليوم " + SimpleDateFormat("EEEE d MMMM", Locale("ar","EG")).format(Date()))
            any(cmd, "اضبط منبه","اعمل منبه","منبه") -> setAlarm(cmd)
            any(cmd, "ابحث عن","دور على","ابحث لي عن","جوجل") -> search(cmd)
            any(cmd, "اكتب رسالة","رسالة واتساب","ابعت واتساب") -> whatsappDraft(cmd)
            any(cmd, "واتساب") -> openPackage("com.whatsapp")
            any(cmd, "يوتيوب") -> openUrl("https://www.youtube.com")
            any(cmd, "كروم","جوجل كروم") -> openPackage("com.android.chrome")
            any(cmd, "الإعدادات","الاعدادات") -> startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            any(cmd, "شغل الكشاف","افتح الكشاف","نور الكشاف") -> torch(true)
            any(cmd, "اقفل الكشاف","اطفي الكشاف") -> torch(false)
            any(cmd, "ارفع الصوت","علي الصوت") -> volume(1)
            any(cmd, "وطي الصوت","خفض الصوت") -> volume(-1)
            any(cmd, "الصفحة الرئيسية","الرئيسية","هوم") -> startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            any(cmd, "مين انت","من انت","اسمك ايه") -> speak("أنا ياسم، مساعدك الصوتي على أندرويد.")
            else -> speak("سمعتك، لكن الأمر ده لسه مش مضاف عندي. قول لي بطريقة أبسط.")
        }
    }

    private fun any(s: String, vararg words: String) = words.any { s.contains(it) }

    private fun openCamera() {
        try {
            startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            speak("حاضر، فتحت الكاميرا")
        } catch (_: Exception) { speak("مش قادر أفتح الكاميرا") }
    }

    private fun setAlarm(cmd: String) {
        val cal = Calendar.getInstance()
        val m = Regex("(\d{1,2})[:.]?(\d{2})?").find(cmd)
        if (m != null) {
            val h = m.groupValues[1].toInt()
            val min = m.groupValues[2].takeIf { it.isNotBlank() }?.toInt() ?: 0
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, h.coerceIn(0,23))
                putExtra(AlarmClock.EXTRA_MINUTES, min.coerceIn(0,59))
                putExtra(AlarmClock.EXTRA_MESSAGE, "منبه من ياسم")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            speak("حاضر، جهزت شاشة ضبط المنبه")
        } else speak("قول لي الساعة، مثلًا: ياسم اضبط منبه الساعة 7")
    }

    private fun search(cmd: String) {
        val q = cmd.replace("ابحث لي عن","").replace("ابحث عن","")
            .replace("دور على","").replace("جوجل","").trim()
        if (q.isBlank()) { speak("قول لي أبحث عن إيه"); return }
        openUrl("https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8"))
        speak("حاضر، فتحت البحث عن $q")
    }

    private fun whatsappDraft(cmd: String) {
        val text = cmd.replace("اكتب رسالة","").replace("رسالة واتساب","")
            .replace("ابعت واتساب","").trim()
        val encoded = URLEncoder.encode(text, "UTF-8")
        openUrl("https://wa.me/?text=$encoded")
        speak("جهزت رسالة واتساب، راجعها واضغط إرسال بنفسك")
    }

    private fun openPackage(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            speak("حاضر")
        } else speak("التطبيق مش موجود على الهاتف")
    }

    private fun openUrl(url: String) {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun torch(on: Boolean) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull() ?: return
            if (Build.VERSION.SDK_INT >= 23) cm.setTorchMode(id, on)
            speak(if (on) "شغلت الكشاف" else "قفلت الكشاف")
        } catch (_: Exception) { speak("مش قادر أتحكم في الكشاف") }
    }

    private fun volume(dir: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
            if (dir > 0) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER, 0)
        speak(if (dir > 0) "عليت الصوت" else "وطيّت الصوت")
    }

    private fun speak(text: String) {
        if (ready) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yasem")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("yasem", "ياسم", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun notification(): Notification =
        Notification.Builder(this, "yasem")
            .setContentTitle("ياسم جاهز")
            .setContentText("قل: ياسم ثم أمرك")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::recognizer.isInitialized) recognizer.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
