package com.example.yasem

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val req = 50

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "ياسم — مساعدك الصوتي"
            textSize = 26f
            setPadding(30, 50, 30, 25)
        }
        val info = TextView(this).apply {
            text = "بعد التشغيل قل: «ياسم» ثم أمرك.\n\nمهم: هذه نسخة تجريبية؛ التشغيل المستمر عبر SpeechRecognizer ليس Wake Word حقيقيًا مثل Siri."
            textSize = 17f
            setPadding(30, 10, 30, 30)
        }
        val button = Button(this).apply {
            text = "تشغيل ياسم في الخلفية"
            setOnClickListener {
                requestNeededPermissions()
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, YasemVoiceService::class.java)
                )
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(info)
            addView(button)
        }
        setContentView(layout)
    }

    private fun requestNeededPermissions() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.CAMERA)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.READ_CONTACTS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            list.add(Manifest.permission.CALL_PHONE)
        ActivityCompat.requestPermissions(this, list.toTypedArray(), req)
    }
}
